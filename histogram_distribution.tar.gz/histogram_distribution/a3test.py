from scipy import stats  
import numpy as np  
import matplotlib.pylab as plt

#list_skew = [0.0001, 0.001, 0.01, 0.1, 1, 2, 3, 4, 5]
list_skew = [0.1, 1]
#dict_skew = {'0.0001': 0.0001, '0.001': 0.001, '0.01': 0.01,'0.1': 0.1 ,'1': 1 ,'10': 10  }

dict_checked = {}
for item in list_skew:
    dict_checked[item] = False

run_log_file = 'a3_output.log'
run_log_channel = open(run_log_file, 'w')
#run_log_channel.write('..done, ' + 'Total duration: {} min {} sec'.format(total_minutes, total_seconds))
#run_log_channel.close()

subplot_index = 1

for x in range(1,10000):
	ser = 10*np.random.normal(0, 100, 1000) + 20
	skewness = stats.skew(ser)
	#print('{0} {1}'.format(x,skewness))

	for i in range(0, len(list_skew)-1):
		if abs(skewness) > abs(list_skew[i]) and abs(skewness) < abs(list_skew[i+1]) and dict_checked[list_skew[i]] == False:
			run_log_channel.write('skewness: {:.6f}'.format(skewness))
			run_log_channel.write('\n------------------------------------------------------\n')
			for item in ser:
				run_log_channel.write(str(item)+'\n')
			run_log_channel.write('\n\n')

			plt.hist(ser, normed=True)
			#print(plt.xticks())
			xt = plt.xticks()[0]
			xmin, xmax = min(xt), max(xt)
			lnspc = np.linspace(xmin, xmax, len(ser))
			m, s = stats.norm.fit(ser)
			pdf_g = stats.norm.pdf(lnspc, m, s)
			this_subplot = plt.subplot(1,1,subplot_index)
			this_subplot.set_title(skewness)
			plt.plot(lnspc, pdf_g, label="Norm")
			subplot_index = subplot_index + 1
			dict_checked[list_skew[i]] = True

run_log_channel.close()
plt.show()
